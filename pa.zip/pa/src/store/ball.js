/**
  *模拟历史数据
  *title, mode, num必填
  *moneyPool, recommend, money, ball选填
 */
const state = {
  history: [
    {
      title: ['2016', '周二21:30'],
      mode: {
        code: 3,
        str: '排5直选：'
      },
      num: {
        red: 5,
        blue: 0
      },
      moneyPool: false,
      recommend: false,
      money: 50,
      ball: { red: [ '02', '04', '03', '17', '23' ], blue: null }
    },
    {
      title: ['2015', '周二21:30'],
      mode: {
        code: 1,
        str: '粤11选5任二幸运号'
      },
      num: {
        red: 2,
        blue: 0
      },
      moneyPool: false,
      recommend: false,
      money: 100,
      ball: { red: ['09', '04'], blue: null }
    },
    {
      title: ['2014', '周二21:30'],
      mode: {
        code: 0,
        str: '复式投注幸运号码'
      },
      num: {
        red: 6,
        blue: 1
      },
      moneyPool: {
        billion: 11,
        million: 777
      },
      recommend: true,
      money: 10,
      ball: { red: [ '07', '04', '03', '18', '27', '05' ], blue: '08' }
    }
  ]
}

// getters
const getters = {
}

// actions
const actions = {
  addHistory({commit}, history) {
    commit('addHistory', history)
  }
}

// mutations
const mutations = {
  addHistory: (state, history) => {
    state.history.unshift(history)
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}
