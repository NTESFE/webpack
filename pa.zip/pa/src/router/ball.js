import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const App = () => import('@module/ball/App')
const Historys = () => import('@components/History')

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: App,
      meta: {
        title: '首页'
      }
    },
    {
      path: '/history',
      name: 'Historys',
      component: Historys,
      meta: {
        title: '历史投注记录'
      }
    }
  ]
})
