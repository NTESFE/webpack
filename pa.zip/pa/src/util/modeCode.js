/**
 * 模式列表
 */
export const mode = [
  {
    code: 0,
    str: '复式投注幸运号码'
  },
  {
    code: 1,
    str: '粤11选5任二幸运号'
  },
  {
    code: 2,
    str: '福彩3D直选幸运号'
  },
  {
    code: 3,
    str: '排5直选'
  },
]