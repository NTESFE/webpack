<template>
  <div class="card-content" :class="{pool : havePool}">
    <p class="card-title">
      <span class="icon"></span>
      <span class="space">第{{title[0]}}期</span>
      <span>{{title[1]}}开奖</span>
    </p>
    <div class="card-selection">
      <div v-if="mode.code === 0">      
        <p class="card-mode">
          <span class="recommend" v-if="recommend"></span>
          <span>{{mode.str}}:</span>
        </p>
        <div class="card-balls">
          <Picker class="card-ball" v-for="(red, index) in redNum" :key="red + index" :no="red" @changeball="changeball(...arguments,index)" :canClick="canClick"/>
          <Picker class="card-ball" v-if="this.num.blue" color="blue" :key="'blue' + blueNum" :no="blueNum" @changeball="changeball" :canClick="canClick"/>
          <span class="fresh" @click="canClick && rotate()" :class="{rot: rot, nofresh: !canClick}"></span>
        </div>
      </div>
      <div v-if="mode.code === 1" class="md1">      
        <div class="card-balls ver">
          <p class="card-mode">
            <span class="recommend" v-if="recommend"></span>
            <span>{{mode.str}}:</span>
          </p>
          <Picker class="card-ball" v-for="(red, index) in redNum" :key="red + index" :no="red" @changeball="changeball(...arguments,index)"/>
          <Picker class="card-ball" v-if="this.num.blue" color="blue" :key="'blue' + blueNum" :no="blueNum" @changeball="changeball"/>
          <span class="fresh" @click="canClick && rotate()" :class="{rot: rot, nofresh: !canClick}"></span>
        </div>
      </div>
      <div v-if="mode.code === 2 || mode.code === 3" class="md1">
        <div class="ver1 baseline">
          <p class="card-mode mode1">
            <span class="recommend" v-if="recommend"></span>
            <span>{{mode.str}}:</span>
          </p>
          <div class="unit" v-for="(red,index) in redNum" :key="red + index">{{unit[redNum.length - 1- index]}}</div>
          <span class="fresh1"></span>
        </div>   
        <div class="card-balls ver1">
          <p class="card-mode">
            <span class="recommend" v-if="recommend"></span>
            <span>{{mode.str}}:</span>
          </p>
          <Picker class="card-ball" v-for="(red, index) in redNum" :key="red + index" :no="red" @changeball="changeball(...arguments,index)" :canClick="canClick"/>
          <Picker class="card-ball" v-if="this.num.blue" color="blue" :key="'blue' + blueNum" :no="blueNum" @changeball="changeball" :canClick="canClick"/>
          <span class="fresh" @click="canClick && rotateUnit()" :class="{rot: rot, nofresh: !canClick}"></span>
        </div>
      </div>
      <div class="card-bt">
        <div class="card-money">
          <moneyPicker @changeMoney="changeMoney" :moneys="money" :canClick="canClick"/>
        </div>
        <div class="card-botton" :class="{notClick :!canClick}" @click="canClick && emit()">
          立即投注
        </div>
      </div>
    </div>
    <div v-if="havePool" class="moneyPool">
      <span class="money-icon"></span>
      <p>奖池<span class="tip" v-for="billion in billions">{{billion}}</span>亿<span class="tip" v-for="million in millions">{{million}}</span>万</p>
    </div>
  </div>
</template>
<script>
  import Picker from '@components/Picker'
  import moneyPicker from '@components/MoneyPicker'
  export default {
    data() {
      return {
        rot: false,
        redNum: this.ball ? this.ball.red : new Array(this.num.red).fill('01'),
        blueNum: this.ball ? this.ball.blue : (this.num.blue !== 0 ? '01' : null),
        money: this.moneys || 10,
        unit: ['个', '十', '百', '千', '万']
      }
    },
    components: {
      Picker,
      moneyPicker
    },
    props: {
      title: {
        type: Array,
        required: true,
        default: function () {
          return ['2018', '周二21:30']
        }
      },
      mode: {
        type: Object,
        required: true,
        default: function () {
          return {
            code: 0,
            str: '复式投注幸运号码'
          }
        }
      },
      num: {
        type: Object,
        required: true,
        default: function() {
          return {
            red: 6,
            blue: 1
          }
        }
      },
      moneyPool: {
        type: [Object, Boolean]
      },
      recommend: {
        type: Boolean
      },
      canClick: {
        type: Boolean,
        default: true
      },
      ball: {
        type: Object
      },
      moneys: {
        type: [Number, String]
      }
    },
    computed: {
      havePool() {
        console.log(this.moneyPool === undefined)
        return !(this.moneyPool === undefined || this.moneyPool === false)
      },
      billions() {
        return this.moneyPool && this.moneyPool.billion.toString().split('')
      },
      millions() {
        return this.moneyPool && this.moneyPool.million.toString().split('')
      }
    },
    methods: {
      emit() {
        this.$emit('showMask')
      },
      rotate() {
        this.rot = true
        for (var i = 0; i < this.num.red; i++) {
          let ran = this.random(1, 33)
          if (ran < 10) {
            ran = '0' + ran
          } else {
            ran = String(ran)
          }
          this.redNum[i] = ran
        }
        if (this.num.blue && (this.num.blue !== 0)) {
          let ran = this.random(1, 16)
          if (ran < 10) {
            ran = '0' + ran
          } else {
            ran = String(ran)
          }
          this.blueNum = ran
        }
        this.redNum.sort()
        setTimeout(() => {
          this.rot = false
        }, 300)
      },
      rotateUnit() {
        this.rot = true
        for (var i = 0; i < this.num.red; i++) {
          let ran = this.random(1, 33)
          if (ran < 10) {
            ran = '0' + ran
          } else {
            ran = String(ran)
          }
          this.redNum[i] = ran
        }
        setTimeout(() => {
          this.rot = false
        }, 300)
      },
      random(lower, upper) {
        return Math.floor(Math.random() * (upper - lower)) + lower
      },
      changeball() {
        if (Array.from(arguments)[0] === 'red') {
          this.redNum[Array.from(arguments)[2]] = Array.from(arguments)[1]
        } else {
          this.blueNum = Array.from(arguments)[1]
        }
      },
      changeMoney(value) {
        this.money = value
      }
    }
  }
</script>
<style lang="less" scoped>
  .card-content {
    position: relative;
    width: 600px;
    height: 290px;
    // border: 1px solid #FFFFFF;
    border-radius: 20px;
    background: #FFFFFF;
    box-sizing: border-box;
    overflow: hidden;
    .card-title {
      display: flex;
      align-items: center;
      margin: 0 20px;
      height: 74px;
      line-height: 74px;
      font-size: 24px;
      color: #666666;
      .icon {
        display: block;
        width: 25px;
        height: 25px;
        background: url(../assets/boot/p.png) no-repeat 0 0;
        background-size: 100% 100%;
        margin-right: 8px;
      }
      .space {
        margin-right: 8px;
      }
    }
    .card-title:after {
      position: absolute;
      content: '';
      width: 560px;
      left: 20px;
      border-bottom: 2px solid #EEEEEE;
      top: 72px;
    }
  }
  .pool {
    height: 360px;
  }
  .card-selection {
    margin: 0 20px;
    font-size: 24px;
    color: #979696;
    .card-mode {
      display: flex;
      align-items: center;
      margin: 12px 0;
      .recommend {
        display: block;
        width: 21px;
        height: 26px;
        background: url(../assets/boot/recommend.png) no-repeat 0 0;
        background-size: 100% 100%;
        margin-right: 8px;
      }
    }
    .card-balls {
      display: flex;
      justify-content: space-around;
      align-items: center;
      width: 100%;
      .fresh {
        display: block;
        width: 35px;
        height: 35px;
        background: url(../assets/boot/fresh.png) no-repeat 0 0;
        background-size: 100% 100%;
      }
      .nofresh {
        visibility: hidden;
      }
    }
    .card-bt {
      width: 100%;
      height: 54px;
      line-height: 54px;
      margin-top: 18px;
      display: flex;
      .card-money {
        width: 124px;
        height: 50px;
        line-height: 50px;
        margin-right: 20px;
        font-size: 24px;
        color: #979696;
        border: 2px solid #EEEEEE;
        border-radius: 10px;
        box-sizing: border-box;
      }
      .card-botton {
        width: 410px;
        height: 100%;
        color: #FFFFFF;
        font-size: 26px;
        text-align: center;
        background: #f2514a;
        border-radius: 10px;
      }
      .notClick {
        background: #a7a3a3;
      }
    }
  }
  .rot {
    animation: rota ease-in-out 0.3s;
    -webkit-animation:rota ease-in-out 0.3s;
    -moz-animation:rota ease-in-out 0.3s;
  }
  @keyframes rota {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(180deg);
    }
  }
  .moneyPool {
    position: absolute;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    width: 100%;
    height: 70px;
    line-height: 70px;
    background: #ffe6e6;
    border-radius: 0 0 20px 20px;
    box-sizing: border-box;
    border: 1px solid #ffe6e6;
    .money-icon {
      display: block;
      width: 26px;
      height: 27px;
      background: url(../assets/boot/pool.png) no-repeat 0 0;
      background-size: 100% 100%;
      margin-right: 8px;
    }
    p {
      display: flex;
      align-items: center;
      font-size: 24px;
      color: #666666;
      letter-spacing: 2px;
      .tip {
        display: inline-block;
        width: 20px;
        height: 30px;
        line-height: 30px;
        border-radius: 6px;
        background: #f2514a;
        font-size: 24px;
        color: #FFFFFF;
        margin-right: 2px;
      }
    }
  }
  .md1 {
    height: 110px;
  }
  .ver {
    display: flex;
    align-items: center;
    height: 110px;
  }
  .ver1 {
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: 55px;
    .mode1 {
      visibility: hidden;
    }
    .fresh1 {
      display: block;
      width: 35px;
      height: 35px;
      background: url(../assets/boot/fresh.png) no-repeat 0 0;
      background-size: 100% 100%;
      visibility: hidden;
    }
    .unit{
      width: 50px;
      height: 50px;
      text-align: center;
    }
  }
  .baseline {
    align-items: baseline;
  }
</style>
