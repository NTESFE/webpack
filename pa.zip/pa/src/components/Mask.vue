<template>
  <div v-show="showMask" class="mask" @touchmove.prevent>
    <slot></slot>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        showMask: false
      }
    },
    methods: {
      show() {
        this.showMask = true
      },
      hide() {
        this.showMask = false
      }
    }
  }
</script>
<style lang="css" scoped>
  .mask {
    /*display: none;*/
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
  }
</style>
