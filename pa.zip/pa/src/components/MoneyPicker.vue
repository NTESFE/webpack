<template>
  <div class="page">
    <div class="money" title="money" is-link :value="money" @click="canClick && (moneyPickerShow = true)">{{text}}元<span class="down"></span></div>
    <wv-picker
      :visible.sync="moneyPickerShow"
      :columns="moneyColumns"
      @confirm="onChange"
    />
  </div>
</template>
<script>
  import Vue from 'vue'
  import { Picker } from 'we-vue'
  import 'we-vue/lib/style.css'
  Vue.use(Picker)
  export default {
    data () {
      return {
        moneyPickerShow: false,
        money: 10,
        moneyColumns: [{
          values: [
            10,
            20,
            50,
            100,
            500
          ],
          defaultIndex: 0
        }],
        text: this.moneys || 10
      }
    },
    methods: {
      onChange (picker, value) {
        this.$nextTick(() => {
          this.text = picker.getValues()[0]
          this.emit(picker.getValues()[0])
        })
      },
      emit(num) {
        this.$emit('changeMoney', num)
      }
    },
    props: {
      canClick: {
        type: Boolean,
        default: true
      },
      moneys: {
        type: [Number, String]
      }
    }
  }
</script>
<style scoped>
.page{
  display: block;
  width: 100%;
  height: 100%;
}
.money {
  width: 100%;
  height: 100%;
  line-height: 50px;
  font-size: 24px;
  color: #979696;
  text-align: center;
}
.down {
  display: inline-block;
  width: 12px;
  height: 12px;
  border-bottom: 3px solid #979696;
  border-right: 3px solid #979696;
  transform: translateY(-30%) rotate(45deg);
  margin-left: 10px;

}
</style>
