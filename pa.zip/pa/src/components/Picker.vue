<template>
  <div class="page">
    <div class="ball" :class="{blue: colors}" title="ball" is-link @click="canClick && (ballPickerShow = true)">{{text}}</div>
    <wv-picker
      :visible.sync="ballPickerShow"
      :columns="ballColumns"
      value-key="name"
      @confirm="onChange"
    />
  </div>
</template>
<script>
  import Vue from 'vue'
  import { Picker } from 'we-vue'
  import 'we-vue/lib/style.css'
  Vue.use(Picker)
  export default {
    data () {
      return {
        ballPickerShow: false,
        ballColumns: [
          {
            values: [
            ]
          }
        ],
        text: this.no || '01'
      }
    },
    props: {
      color: {
        type: String,
        default: 'red'
      },
      no: {
        type: String
      },
      canClick: {
        type: Boolean,
        default: true
      }
    },
    computed: {
      colors() {
        return this.color === 'blue'
      }
    },
    created() {
      if (!this.colors) {
        for (let i = 0; i < 33; i++) {
          if (i < 9) {
            this.ballColumns[0].values.push('0' + (i + 1))
          } else {
            this.ballColumns[0].values.push(String(i + 1))
          }
        }
      } else {
        for (let i = 0; i < 16; i++) {
          if (i < 9) {
            this.ballColumns[0].values.push('0' + (i + 1))
          } else {
            this.ballColumns[0].values.push(String(i + 1))
          }
        }
      }
    },
    methods: {
      onChange (picker, value) {
        this.$nextTick(() => {
          this.text = picker.getValues()[0]
          this.emit(this.color, picker.getValues()[0])
          // console.log(picker.getValues())
        })
      },
      emit(color, num) {
        this.$emit('changeball', color, num)
      }
    }
  }
</script>
<style scoped>
.page{
  display: inline-block;
}
.ball {
  width: 50px;
  height: 50px;
  line-height: 50px;
  border-radius: 50px;
  font-size: 30px;
  color: #FFFFFF;
  background: #F2514A;
  text-align: center;
}
.blue {
  background: #4493F4;
}
</style>
