<template>
  <div class="content">
    <card class="card" v-for="(history, index) in historys" :key="history.mode.code + index" :canClick="false" :moneyPool="history.moneyPool" :num="history.num" :title="history.title" :mode="history.mode" :recommend="history.recommend" :ball="history.ball" :moneys="history.money"/>
  </div>
</template>
<script>
  import card from '@components/Card'
  export default {
    data() {
      return {
      }
    },
    computed: {
      historys() {
        return this.$store.state.ball.history
      }
    },
    components: {
      card
    }
  }
</script>
<style lang="less" scoped>
  .content {
    position: absolute;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 50px;
  }
  .card {
    margin: 50px auto 0;
  }
</style>
