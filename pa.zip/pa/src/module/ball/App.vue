<template>
  <div class="content">
    <card class="card" ref="cardRef" @showMask="showMask" :moneyPool="moneyPool" :num="num" :title="title" :mode="mode" :recommend="recommend"/>
    <!-- <card class="card" ref="cardRef" @showMask="showMask" :num="num" :title="title" :mode="mode"/> -->
    <div class="rule">
      <p>规则说明</p>
      <p class="p">规则说明规则说明规则说明规则说明规则说明规则说明规则说明规则说明规则说明规则说明规则说明</p>
    </div>
    <router-link to="./history" class="history">历史记录</router-link>
    <transition name="show">
      <commonMask ref="maskRef">
        <div v-if="showSuccess" class="cancel-dialog">
          <div class="dialog-header">
            <span>是否确认投注?</span>
          </div>
          <div class="dialog-actions">
            <div @touchstart.prevent.stop="cancelDialog" class="dialog-action">
              <span>取消</span>
            </div>
            <div @touchstart.prevent.stop="confirmDialog" class="dialog-action">
              <span>确认</span>
            </div>
          </div>
        </div>
        <div v-if="!showSuccess" class="succes">
          <p>投注成功</p>
        </div>
      </commonMask>
    </transition>
  </div>
</template>
<script>
  import card from '@components/Card'
  import commonMask from '@components/Mask'
  export default {
    data() {
      return {
        title: ['2018', '周二21:30'],
        mode: {
          code: 0,
          str: '复式投注幸运号码'
        },
        num: {
          red: 6,
          blue: 1
        },
        moneyPool: {
          billion: 110,
          million: 580
        },
        recommend: true,
        showSuccess: true
      }
    },
    components: {
      card,
      commonMask
    },
    methods: {
      showMask() {
        this.$refs.maskRef.show()
      },
      cancelDialog() {
        console.log('cancelDialog')
        this.$refs.maskRef.hide()
      },
      confirmDialog() {
        let history = {
          title: this.title,
          mode: this.mode,
          recommend: this.recommend || false,
          num: this.num,
          moneyPool: this.moneyPool || false,
          ball: {
            red: this.$refs.cardRef.redNum,
            blue: this.$refs.cardRef.blueNum
          },
          money: this.$refs.cardRef.money
        }
        console.log(history)
        this.$store.dispatch('addHistory', history)
        this.showSuccess = false
        setTimeout(() => {
          this.$refs.maskRef.hide()
          this.showSuccess = true
        }, 1000)
      }
    }
  }
</script>
<style lang="less" scoped>
  * {
    margin: 0;
    padding: 0;
  }
  .content {
    width: 100%;
    /* height: 100vh; */
    height: 1016px;
    display: flex;
    justify-content: center;
    background: url(../../assets/boot/background.jpg) no-repeat 0 0;
    background-size: 100% 100%;
    position: relative;
    max-width: 640px;
    margin: 0 auto;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    -webkit-overflow-scrolling: touch;
    user-select: none;
  }
  .card {
    position: absolute;
    top: 300px;
  }
  .rule {
    position: absolute;
    top: 700px;
    width: 100%;
    text-align: center;
    p {
      display: inline-block;
      font-size: 30px;
      color: #8e2424;
    }
    p:before {
      position: absolute;
      top: 20px;
      left: 61px;
      content: '';
      width: 179px;
      border-bottom: 2px solid #8e2424;
    }
    p:after {
      position: absolute;
      top: 20px;
      right: 61px;
      content: '';
      width: 179px;
      border-bottom: 2px solid #8e2424;
    }
    .p {
      width: 100%;
      box-sizing: border-box;
      font-size: 24px;
      color: #8e2424;
      padding: 26px 42px 0;
      text-align: left;
    }
  }
  .cancel-dialog {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    width: 480px;
    height: 165px;
    background: #FFFFFF;
    border-radius: 10px;
    overflow: hidden;
    .dialog-header {
      height: 90px;
      line-height: 90px;
      text-align: center;
      font-size: 24px;
    }
    .dialog-actions {
      display: flex;
      height: 75px;
      border-top: 1px solid #DDDDDD; /*no*/
    }
    .dialog-action {
      width: 240px;
      height: 75px;
      line-height: 75px;
      text-align: center;
      font-size: 24px;
      color: #F05A23;
      border-left: 1px solid #DDDDDD; /*no*/
    }
  }
  .show-enter-active, .show-leave-active{
    transition: all 1s cubic-bezier(0.86, 0.18, 0.82, 1.32);
  }
  .show-enter, .show-leave-to {
    opacity: 0;
  }
  .history {
    position: absolute;
    top: 20px;
    right: 20px;;
    font-size: 20px;
    color: #FFFFFF;
    text-decoration: underline;
  }
  .succes {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    width: 240px;
    height: 80px;
    background: #FFFFFF;
    border-radius: 10px;
    overflow: hidden;
    p {
      font-size: 30px;
      color: #8e2424;
      line-height: 80px;
      text-align: center;
    }
  }
</style>