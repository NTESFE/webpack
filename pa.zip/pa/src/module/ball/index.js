import Vue from 'vue'
import App from './App'
import 'lib-flexible/flexible.js'
import store from '@store/index'
import router from '@router/ball'
/* eslint-disable no-new */
router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title
  }
  next()
})

new Vue({
  template: '<router-view></router-view>',
  components: { App },
  store,
  router
}).$mount('#app')
